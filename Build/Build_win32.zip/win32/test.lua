function test1()
	print("OK")
	test4();
end